public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello from jenkins CI/CD pipeline");
    }
}